from django.apps import AppConfig


class AuthorConfig(AppConfig):
    name = 'author'
